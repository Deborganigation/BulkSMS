# Bulk SMS Sender - GitHub Project

## GitHub Pe Upload Kaise Karein

### Step 1: GitHub Repository Create
- GitHub → New Repository → "BulkSMS" → Create

### Step 2: Files Upload
- Add files → Upload files
- Ya Git use karo:

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/BulkSMS.git
git push -u origin main
```

### Step 3: APK Build
- Actions tab → Build APK workflow
- Wait for build
- Artifacts → Download APK

## CSV Format
```csv
Name,Phone
Rahul,9876543210
Priya,8765432109
```

## Features
- Auto bulk SMS send
- CSV import
- Delay between messages
- Progress tracking
